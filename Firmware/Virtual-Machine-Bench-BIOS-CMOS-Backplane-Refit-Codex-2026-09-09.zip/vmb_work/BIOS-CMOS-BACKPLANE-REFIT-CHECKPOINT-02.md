# BIOS/CMOS Backplane Refit — Checkpoint 02

Date: 2026-09-09
Status: source integration milestone; NASM/Visual Studio validation still required.

Completed since Checkpoint 01:

- preserved exact pre-edit active BIOS ASM/LST/ROM under `Firmware/Backup - pre BIOS CMOS backplane refit 2026-09-09/`;
- added real PIT2/port-61h POST beep source;
- added optional 80287 guest-visible probe and CMOS/BDA equipment-bit synchronization;
- added four-position primary/secondary, master/slave IDE ATA/ATAPI/Empty reset-signature inventory;
- guarded primary-master IDENTIFY so Empty/ATAPI sockets are not sent ATA IDENTIFY;
- added Fast/Thorough memory POST CMOS option;
- added keyboard-error halt Yes/No CMOS option;
- made POST/Setup report detected NPX/video/IDE population rather than fixed 80287/Diamond text;
- installed INT 18h ROM BASIC fallback;
- embedded user-supplied IBM BASIC ROM at historical F6000h-FDFFFh; no dynamic overlay required because the Phalanx code/data remains below offset 6000h by design;
- added hardened `Firmware/build-bios.ps1` + `.cmd` wrapper with BASIC hash/window validation;
- added Codex validation/compile instructions and exact source diff.

IBM BASIC identity:
- 32768 bytes
- SHA-256 `3033d1a54c99d7e2aa1fc7c8c2e51a56ae1b61bf4e70e8aa580f43c43e37a63e`

Static checks at this checkpoint:
- 142 BIOS global labels, zero duplicates;
- preprocessor conditional count balanced;
- 55 VB Compile entries / 55 unique;
- two pre-existing missing generated VB files remain: `My Project\\Resources.Designer.vb`, `My Project\\Settings.Designer.vb`;
- ProcessorCore, ProcessorTiming, Intel80287, HardwarePopulation, and IsaBackplane are byte-identical to the incoming hardware-population refit.

Pending validation:
- NASM assembly is unavailable in the assistant container;
- Codex/Windows must run `Firmware/build-bios.ps1` and then build the VB.NET project;
- runtime smoke matrix is in `CODEX-VALIDATE-BIOS-CMOS-BACKPLANE.md`.
