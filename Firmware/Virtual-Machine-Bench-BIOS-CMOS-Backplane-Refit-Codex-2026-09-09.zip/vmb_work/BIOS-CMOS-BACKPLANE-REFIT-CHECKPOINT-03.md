# BIOS/CMOS Backplane Refit — Checkpoint 03 / Codex handoff

Date: 2026-09-09
Status: source refit complete; external NASM + VB.NET validation required.

Final source additions beyond Checkpoint 02:

- first accepted Delete now sends keyboard Disable Scanning, drains protocol/repeat residue and clears the BIOS ring while IRQ1 is owned by POST;
- CMOS Setup explicitly sends Enable Scanning after taking ownership and clears trigger residue;
- Main / Advanced / Boot / Exit tabs are functional Left/Right pages rather than decorative labels;
- completed POST roll-up reports detected 80287/video-option-ROM population plus all four IDE positions;
- stale active `Firmware/atbios.rom` and `Firmware/atbios.lst` were intentionally removed from the handoff so Codex must assemble the new source before the VB build; exact old versions remain in the pre-refit backup;
- `Firmware/build-bios.ps1` validates BASIC identity, 64 KiB ROM size, FFF0 reset vector and exact F6000h-FDFFFh BASIC bytes before publishing generated ROM/listing.

Static final checks:

- 153 BIOS global labels, zero duplicates;
- no 386-style near conditional Jcc syntax in `cpu 286` source;
- `%if/%endif` balanced;
- BASIC is exactly 32768 bytes, SHA-256 `3033d1a54c99d7e2aa1fc7c8c2e51a56ae1b61bf4e70e8aa580f43c43e37a63e`;
- CPU core, timing, Intel80287, HardwarePopulation and IsaBackplane remain byte-identical to the incoming hardware-population refit;
- VB project has 55 Compile entries / 55 unique; the same two pre-existing generated `My Project` files are absent and were not fabricated.

Use `CODEX-VALIDATE-BIOS-CMOS-BACKPLANE.md` as the validation script/checklist.
