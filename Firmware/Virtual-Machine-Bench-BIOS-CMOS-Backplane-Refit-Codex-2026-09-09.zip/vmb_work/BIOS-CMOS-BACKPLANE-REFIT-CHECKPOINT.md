# Virtual Machine Bench — BIOS/CMOS Backplane Refit Checkpoint

Date: 2026-09-09
Checkpoint: 01 — recovery and integration baseline

## Authoritative working base
- Hardware-population refit source produced from the user's `9-9-20261AM.zip`.
- CPU, numeric coprocessor, video, audio, and network population are physical/removable and support `None` where applicable.
- CPU/80287 pre-refit green backups remain preserved under the sorted hardware folders.

## BIOS source being refit
- `Firmware/atbios.asm` is the active BIOS source.
- `Firmware/Backup - pre revision/` is historical only and must not replace the active source.
- Active BIOS already contains CMOS validation/checksum, protected-mode extended-memory POST, keyboard/controller POST, setup-entry windows, ATA support, and Cromwell CMOS Setup scaffolding.

## Confirmed missing/incomplete behavior to finish
1. POST beep: active BIOS has no functional PIT2/port-61h POST-tone sequence.
2. Storage discovery: current POST path still calls the older `ata_detect` path and does not yet represent all four IDE positions as first-class detected population.
3. Empty storage is valid: POST must complete cleanly with all IDE positions empty and must not wait on nonexistent devices.
4. BASIC fallback: user supplied `basic110.rom` (32 KiB IBM Cassette BASIC). It is present in `Firmware/basic110.rom` for this refit.
5. BASIC must not permanently overlap the AT BIOS ROM window. Planned implementation is a disabled-by-default firmware ROM overlay/bank device enabled only after the BIOS exhausts boot-device search with no usable storage/boot media, followed by guest-visible transfer into the BASIC ROM. Reset/power-cycle disables the overlay again.
6. CMOS setup/presentation must report current physical CPU/NPX/ISA population instead of hardcoded installed devices. CMOS remains firmware/motherboard policy; removable board population remains the backplane's authority.

## User-requested integration policy
- Do not use fake disable flags for removable hardware.
- Do not host-intercept boot or BASIC execution.
- Do not copy BASIC into RAM as a shortcut.
- No-drive configuration is a legitimate machine configuration.
- Firmware should POST, beep, report empty drives, search boot devices, then enter BASIC as the final fallback.

## Validation handoff target
Codex/Visual Studio should validate:
- NASM assembly and exact 64 KiB AT BIOS ROM fit/checksum.
- VB.NET compile after firmware/backplane ROM-overlay changes.
- POST with ordinary populated machine.
- POST with no IDE devices.
- POST beep audible through the existing PC speaker path.
- No-drive/no-boot path maps BASIC only at fallback time and reaches BASIC.
- Reset/power-cycle removes the BASIC overlay.
- CPU/NPX/ISA `None` states remain electrically absent and BIOS/setup reporting does not fabricate them.

This checkpoint intentionally records the recovered baseline before the remaining BIOS/backplane changes are applied.
