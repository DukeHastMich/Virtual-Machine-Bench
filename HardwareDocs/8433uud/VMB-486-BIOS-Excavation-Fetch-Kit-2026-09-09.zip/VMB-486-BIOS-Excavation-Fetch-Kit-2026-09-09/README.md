# VMB 486 BIOS Excavation Fetch Kit

Target boards:
1. BIOSTAR MB-8433UUD-A — UMC UM8881F/UM8886BF
2. MSI MS-4144 — SiS 496/497; especially valuable because both AMI and Award BIOS families survive
3. ABIT PB4 — ALi M1489/M1487
4. ASUS PCI/I-486SP3G — Intel 420ZX Saturn II
5. FIC 486-GIO-VT2 — VIA VT82C486A / VLB

## Why this is a fetch kit instead of the BIOS binaries themselves
The research environment could resolve/index the public archive pages and GitHub repository metadata,
but its execution container could not establish outbound binary-download connections. Rather than pretend
the ROMs were downloaded, this package contains the exact discovered URLs plus a PowerShell fetcher.

Run:

    powershell -ExecutionPolicy Bypass -File .\Fetch-VMB-486-BIOSes.ps1

It downloads the original archive mirrors and useful 86Box raw ROM fallbacks, computes SHA-256 for every
downloaded file, writes DOWNLOAD-HASHES.csv, then creates:

    VMB-486-BIOS-Excavation-Pack-2026-09-09.zip

Nothing downloaded is executed.

## Archaeology notes
- The MSI MS-4144 is particularly useful: AF54S/AF53 are AMI while WF53S/WF54S are Award, on the same board.
- The ASUS SP3G gives Award 4.50G vs later 4.51G beta-era behavior.
- The Biostar pack includes both the last official UUD960520S lineage and Feipoa's UUD2014 revision.
- The FIC 486-GIO-VT2 gives a VIA/VLB-era target rather than another PCI-only 486.
- `manifest.csv` and `manifest.json` preserve provenance and known reference hashes.

Do not flash any of these into real hardware without independently confirming board revision and ROM size.
For VMB archaeology, preserve original archives unchanged and work on extracted copies.
