﻿$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$out  = Join-Path $here "Downloaded"
New-Item -ItemType Directory -Force -Path $out | Out-Null

$items = @(
    [pscustomobject]@{ Board='BIOSTAR MB-8433UUD-A'; Version='Last official set / UUD960520S'; Kind='archive'; File='Biostar_8433UUD_last_official_BIOS.zip'; Url='https://vogonsdrivers.com/files/downloader.php?fileid=557' },
    [pscustomobject]@{ Board='BIOSTAR MB-8433UUD-A'; Version='UUD2014 by Feipoa'; Kind='archive'; File='biostar_mb-8433uud-bios-vuud2014.zip'; Url='https://vogonsdrivers.com/files/downloader.php?fileid=947' },
    [pscustomobject]@{ Board='BIOSTAR MB-8433UUD-A'; Version='UUD960520S raw'; Kind='raw-rom'; File='uud0520s.bin'; Url='https://raw.githubusercontent.com/86Box/roms/master/machines/84xxuuda/uud0520s.bin' },
    [pscustomobject]@{ Board='MSI MS-4144'; Version='AF54S'; Kind='archive'; File='MS4144_AF54S.7z'; Url='https://soggi.org/files/motherboards/bios/msi/MS4144_AF54S.7z' },
    [pscustomobject]@{ Board='MSI MS-4144'; Version='AF53'; Kind='archive'; File='MS4144_AF53.7z'; Url='https://soggi.org/files/motherboards/bios/msi/MS4144_AF53.7z' },
    [pscustomobject]@{ Board='MSI MS-4144'; Version='WF53S'; Kind='archive'; File='MS4144_WF53S.7z'; Url='https://soggi.org/files/motherboards/bios/msi/MS4144_WF53S.7z' },
    [pscustomobject]@{ Board='MSI MS-4144'; Version='WF54S'; Kind='archive'; File='MS4144_WF54S.7z'; Url='https://soggi.org/files/motherboards/bios/msi/MS4144_WF54S.7z' },
    [pscustomobject]@{ Board='MSI MS-4144'; Version='1.4 raw'; Kind='raw-rom'; File='ms-4144-1.4.bin'; Url='https://raw.githubusercontent.com/86Box/roms/master/machines/ms4144/ms-4144-1.4.bin' },
    [pscustomobject]@{ Board='ABIT PB4'; Version='F2'; Kind='archive'; File='PB4_F2.7z'; Url='https://soggi.org/files/motherboards/bios/abit/PB4_F2.7z' },
    [pscustomobject]@{ Board='ABIT PB4'; Version='F2 raw'; Kind='raw-rom'; File='486-AB-PB4.BIN'; Url='https://raw.githubusercontent.com/86Box/roms/master/machines/abpb4/486-AB-PB4.BIN' },
    [pscustomobject]@{ Board='ASUS PCI/I-486SP3G'; Version='0304'; Kind='archive'; File='PCII486SP3G_0304.7z'; Url='https://soggi.org/files/motherboards/bios/asus/PCII486SP3G_0304.7z' },
    [pscustomobject]@{ Board='ASUS PCI/I-486SP3G'; Version='0306.001 beta'; Kind='archive'; File='PCII486SP3G_0306001_beta.7z'; Url='https://soggi.org/files/motherboards/bios/asus/PCII486SP3G_0306001_beta.7z' },
    [pscustomobject]@{ Board='ASUS PCI/I-486SP3G'; Version='0306.001 beta raw'; Kind='raw-rom'; File='PCI-I-486SP3G_0306.001 (Beta).bin'; Url='https://raw.githubusercontent.com/86Box/roms/master/machines/486sp3g/PCI-I-486SP3G_0306.001%20(Beta).bin' },
    [pscustomobject]@{ Board='FIC 486-GIO-VT2'; Version='3.26G'; Kind='archive'; File='486GIOVT2_326G.7z'; Url='https://soggi.org/files/motherboards/bios/fic/486GIOVT2_326G.7z' },
)

$headers = @{
    "User-Agent" = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) VMB-Archive-Fetch/1.0"
}

$results = @()
foreach ($i in $items) {
    $boardDir = Join-Path $out (($i.Board -replace '[\\/:*?"<>|]', '_'))
    New-Item -ItemType Directory -Force -Path $boardDir | Out-Null
    $dest = Join-Path $boardDir $i.File

    Write-Host ("Fetching {0} / {1} -> {2}" -f $i.Board, $i.Version, $i.File)
    try {
        Invoke-WebRequest -Uri $i.Url -OutFile $dest -Headers $headers -MaximumRedirection 10 -UseBasicParsing
        $h = Get-FileHash -Algorithm SHA256 -Path $dest
        $results += [pscustomobject]@{
            Board=$i.Board; Version=$i.Version; Kind=$i.Kind; File=$i.File
            Bytes=(Get-Item $dest).Length; SHA256=$h.Hash.ToLowerInvariant()
            URL=$i.Url; Status="OK"
        }
    }
    catch {
        Write-Warning ("FAILED: {0}" -f $_.Exception.Message)
        $results += [pscustomobject]@{
            Board=$i.Board; Version=$i.Version; Kind=$i.Kind; File=$i.File
            Bytes=0; SHA256=""; URL=$i.Url; Status=("FAILED: " + $_.Exception.Message)
        }
    }
}

$csv = Join-Path $here "DOWNLOAD-HASHES.csv"
$results | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csv

$ok = $results | Where-Object { $_.Status -eq "OK" }
Write-Host ""
Write-Host ("Downloaded {0}/{1} resources." -f $ok.Count, $items.Count)
Write-Host ("Hash manifest: {0}" -f $csv)

$zip = Join-Path $here "VMB-486-BIOS-Excavation-Pack-2026-09-09.zip"
if (Test-Path $zip) { Remove-Item $zip -Force }

# Put downloads and provenance files into the final excavation ZIP.
$staging = Join-Path $here "_pack_staging"
if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
New-Item -ItemType Directory -Path $staging | Out-Null
Copy-Item -Recurse -Path $out -Destination $staging
Copy-Item -Path (Join-Path $here "README.md"), (Join-Path $here "manifest.csv"), (Join-Path $here "manifest.json"), $csv -Destination $staging
Compress-Archive -Path (Join-Path $staging "*") -DestinationPath $zip -CompressionLevel Optimal
Remove-Item $staging -Recurse -Force

Write-Host ("Final pack: {0}" -f $zip)
Write-Host ("Pack SHA256: {0}" -f ((Get-FileHash -Algorithm SHA256 -Path $zip).Hash.ToLowerInvariant()))
