Mainboard HOT-419
=================

5/96
Latest AMI-Bios 419AIP06.BIN for HOT419DZ
(no Flash-Bios programming possible)