# SB16 conformance-test targets from the recovered sources

The original Creative software should be treated as black-box guest-visible tests, not as
something to special-case inside VMB.

## High-value tests

### DIAGNOSE / install-time detection
- Base I/O decode
- DSP reset timing and 0xAA response
- DSP version query
- IRQ discovery/acknowledgement
- DMA channel selection and actual transfer completion
- Mixer register visibility
- MPU-401 presence/status behavior
- PnP/non-PnP behavior only where appropriate to the selected SB16 revision

### DMA
Creative's 1996 hardware programming guide explicitly documents the odd-but-real case:
SB16 can transfer **16-bit audio using an 8-bit DMA channel** after SBCONFIG configures it.
In that mode BLASTER `D` and `H` can name the same low DMA channel.

That is a very useful VMB stress test because the emulated sample width and the ISA DMA
channel width are not the same concept.

Audit against the Intel 8237A documentation:
- DREQ/DACK lifetime and polarity
- terminal count / EOP
- current/base address and count reload
- auto-init
- single/block/demand transfer semantics
- low-vs-high AT DMA controller behavior in the machine implementation

### IRQ/PIC
SB16 DSP 4.xx shares an IRQ among 8-bit DMA, 16-bit DMA, SB-MIDI, and MPU-401 UART
sources.  Audit:
- mixer interrupt-status register
- source-specific acknowledgement port
- IRQ line deassertion/reassertion
- 8259 IRR/ISR transitions
- INTA and EOI handling
- no magical clearing of a still-asserted device condition

### MPU-401 UART
Use both the Roland MPU-401 Technical Reference and Creative's SB16 guide.  The original
Roland manual is the broader device reference; Creative documents the SB16's UART-mode
mapping and interrupt sharing.

### OPL3
Audit the actual Yamaha YMF262 register/timer/status behavior.  Do not infer OPL3 behavior
from a host synthesizer or SoundFont path.

### Wave Blaster
A host SoundFont may remain a *backend* for a selected daughterboard implementation, but the
guest-visible connector boundary should still obey the real 26-pin electrical contract:
MIDI/reset/power/analog-return presence and physical absence when no daughterboard is fitted.
