# Wave Blaster 26-pin header — VMB cross-check

## Canonical numbering source

For VMB, treat Creative's own **Sound Blaster 16 Getting Started**, Table D-15, as the
pin-numbering authority.  The table is a conventional 2x13 header: odd pins down one
column, even pins down the other.

| Pin | Creative description | Pin | Creative description |
|---:|---|---:|---|
| 1 | Digital Ground | 2 | NC |
| 3 | Digital Ground | 4 | MIDI Output |
| 5 | Digital Ground | 6 | VCC |
| 7 | Digital Ground | 8 | MIDI Input |
| 9 | Digital Ground | 10 | VCC |
| 11 | Digital Ground | 12 | NC |
| 13 | NC | 14 | VCC |
| 15 | Analog Ground | 16 | NC |
| 17 | Analog Ground | 18 | +12 V |
| 19 | Analog Ground | 20 | Line In: Right |
| 21 | Analog Ground | 22 | -12 V |
| 23 | Analog Ground | 24 | Line In: Left |
| 25 | Analog Ground | 26 | ResetB |

### Electrical interpretation for an emulated host/card boundary

Do **not** infer direction only from the English word “Input” or “Output” without first
defining the point of view of the Creative table.  Canonize the physical pin numbers first,
then verify signal direction against the actual SB16/daughterboard path when wiring the
emulator.

The header must model at least:
- TTL-level MIDI path
- active-low ResetB
- +5 V, +12 V and -12 V rails
- digital vs analog grounds
- stereo analog return from the daughterboard into the SB16 mixer path
- NC pins as electrically unconnected

## Why the internet diagrams disagree

ePanorama preserves three useful historical versions:
1. a corrected 2x13 pinout whose *physical pattern* agrees with the Creative-style header,
2. an Elektor diagram with a different pin-numbering convention,
3. a widely reposted Usenet table that ePanorama explicitly marks as **wrong**.

That makes the Creative manual the correct numbering authority for VMB.  Keep the
ePanorama page in the archive as a “do not regress into this numbering trap” reference.

Sources:
- Creative SB16 Getting Started / Table D-15:
  https://manualzz.com/doc/68303449/creative-structures-sound-blaster-16-getting-started
- ManualsLib mirror:
  https://www.manualslib.com/manual/1834637/Creative-Structures-Sound-Blaster-16.html
- ePanorama cross-check:
  https://www.epanorama.net/documents/pc/waveblaster.html
