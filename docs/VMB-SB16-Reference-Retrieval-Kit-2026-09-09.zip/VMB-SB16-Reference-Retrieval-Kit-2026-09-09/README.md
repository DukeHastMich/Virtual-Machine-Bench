# VMB SB16 reference retrieval kit — 2026-09-09

This kit records the original/period references needed for a full Sound Blaster 16 refit:
Roland MPU-401, Intel DMA/PIC, Yamaha OPL3, Creative DOS/Windows 3.1 software, and the
Wave Blaster header.

## Important extra find

Creative's own **Sound Blaster Series Hardware Programming Guide** (1996, 141 pages) is in
the manifest.  It is probably the single most useful SB16-specific source in the set: DSP,
mixer, IRQ sharing/acknowledgement, MPU-401 UART, and the strange-but-real 16-bit audio over
a low DMA channel case are all documented there.

## Retrieval

Run:

    powershell -ExecutionPolicy Bypass -File .\Fetch-VMB-SB16-References.ps1

The script:
- downloads direct public archive/mirror resources into `Downloaded\`
- queries Archive.org metadata for the Roland scan instead of guessing its PDF filename
- saves source/index pages where a mirror uses dynamic links
- computes SHA-256 for every successfully retrieved file
- writes `DOWNLOAD-HASHES.csv`
- produces `VMB-SB16-Reference-Pack-2026-09-09.zip`

Nothing downloaded is executed.

Some old archive hosts deliberately block scripted or hot-linked downloads.  If one item
fails, the corresponding `source_url` in manifest.csv is the provenance/interactive fallback.

## Why the files are not pre-bundled here

This ChatGPT execution container cannot establish the binary download connections to these
archive hosts.  Also, several manuals/software packages retain vendor copyright/licence text.
This kit therefore preserves provenance and retrieves the originals directly from the
archive/mirror to your machine rather than re-publishing their bytes as a new distribution.

## Wave Blaster

Read `WAVEBLASTER-PINOUT-CROSSCHECK.md` before touching the VMB connector model.  It uses
Creative Table D-15 as the numbering authority and records the known conflicting internet
numbering trap.

## Primary target set

- Roland MPU-401 Technical Reference Manual
- Intel 8237A — Order 231466-005
- Intel 8259A — Order 231468-003
- Yamaha YMF262 datasheet/catalog
- Yamaha YMF262 OPL3 application manual source
- Creative Sound Blaster Series Hardware Programming Guide
- Creative SB16 Value Edition Revision 1 DOS/Windows disk images
- Creative SB16 install/disk alternatives
- Creative SB16 Getting Started hardware manual / Wave Blaster Table D-15
- ePanorama Wave Blaster numbering cross-check
