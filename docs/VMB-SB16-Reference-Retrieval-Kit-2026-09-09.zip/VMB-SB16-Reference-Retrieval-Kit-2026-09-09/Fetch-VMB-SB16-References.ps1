﻿$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$out = Join-Path $here "Downloaded"
New-Item -ItemType Directory -Force -Path $out | Out-Null

$headers = @{
  "User-Agent" = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) VMB-SB16-Archive-Fetch/1.0"
}

$results = New-Object System.Collections.Generic.List[object]

function Add-Result {
    param($Title,$File,$Url,$Status)
    $path = Join-Path $out $File
    if ((Test-Path $path) -and $Status -eq "OK") {
        $h = Get-FileHash -Algorithm SHA256 -Path $path
        $bytes = (Get-Item $path).Length
        $results.Add([pscustomobject]@{
            Title=$Title; File=$File; Bytes=$bytes;
            SHA256=$h.Hash.ToLowerInvariant(); URL=$Url; Status=$Status
        })
    } else {
        $results.Add([pscustomobject]@{
            Title=$Title; File=$File; Bytes=0; SHA256=""; URL=$Url; Status=$Status
        })
    }
}

function Fetch {
    param(
        [string]$Title,
        [string]$Url,
        [string]$File
    )
    $dest = Join-Path $out $File
    Write-Host ("Fetching: {0}" -f $Title)
    try {
        Invoke-WebRequest -Uri $Url -OutFile $dest -Headers $headers -MaximumRedirection 10 -UseBasicParsing -ErrorAction Stop
        Add-Result $Title $File $Url "OK"
    } catch {
        $msg = "FAILED: " + $_.Exception.Message
        Write-Warning $msg
        Add-Result $Title $File $Url $msg
    }
}

# Roland: ask Internet Archive for the actual item files so we don't guess a filename.
Write-Host "Resolving Roland MPU-401 Technical Reference from Archive.org metadata..."
$iaItem = "mpu401technicalreferencemanual"
try {
    $metaUrl = "https://archive.org/metadata/$iaItem"
    $meta = Invoke-RestMethod -Uri $metaUrl -Headers $headers -ErrorAction Stop
    $pdfs = @($meta.files | Where-Object {
        $_.name -match '\.pdf$' -and $_.name -notmatch '(_text|_bw|_jp2|_chocr)'
    })
    if ($pdfs.Count -eq 0) {
        $pdfs = @($meta.files | Where-Object { $_.name -match '\.pdf$' })
    }
    if ($pdfs.Count -gt 0) {
        # Prefer the largest PDF; generally the HQ/original scan.
        $pick = $pdfs | Sort-Object { [long]($_.size -as [long]) } -Descending | Select-Object -First 1
        $escaped = ($pick.name -split '/' | ForEach-Object {[uri]::EscapeDataString($_)}) -join '/'
        $url = "https://archive.org/download/$iaItem/$escaped"
        Fetch "Roland MPU-401 Technical Reference Manual" $url "Roland_MPU-401_Technical_Reference.pdf"
    } else {
        Add-Result "Roland MPU-401 Technical Reference Manual" "Roland_MPU-401_Technical_Reference.pdf" "https://archive.org/details/$iaItem" "FAILED: Archive item contained no PDF entry"
    }
} catch {
    Write-Warning ("Archive.org metadata failed: " + $_.Exception.Message)
    # Independent scan mirror fallback.
    Fetch "Roland MPU-401 Technical Reference Manual (fallback)" `
      "https://manuals.plus/m/6f00eef224f8006d24c5b5fbd05eb95846761efa9f829f11d6383445867b297d.pdf" `
      "Roland_MPU-401_Technical_Reference.pdf"
}

Fetch "Intel 8237A High Performance Programmable DMA Controller, 231466-005" `
  "https://mark-ogden.uk/files/intel/publications/231466-005%208237A%20High%20Performance%20Programmable%20DMA%20Controler%20%288237A-5%29-Sep93.pdf" `
  "Intel_231466-005_8237A_DMA_Sep1993.pdf"

Fetch "Intel 8259A Programmable Interrupt Controller, 231468-003" `
  "https://mark-ogden.uk/files/intel/publications/231468-003%208259A%20Programmable%20Interrupt%20Controller%20%288259A_8259A-2%29-Dec88.pdf" `
  "Intel_231468-003_8259A_PIC_Dec1988.pdf"

Fetch "Yamaha YMF262 OPL3 datasheet/catalog 1994.11" `
  "https://map.grauw.nl/resources/sound/yamaha_ymf262.pdf" `
  "Yamaha_YMF262_OPL3_Datasheet_1994-11.pdf"

Fetch "Creative Sound Blaster Series Hardware Programming Guide" `
  "https://www.phatcode.net/downloads.php?action=get&file=sbhwpg.pdf&id=243" `
  "Creative_Sound_Blaster_Series_Hardware_Programming_Guide_1996.pdf"

Fetch "SB16 Value Edition Drivers & Applications disk set Revision 1" `
  "https://ftpmirror2.infania.net/sites/Creative%20Labs/Sound%20Blaster%2016/Sound%20Blaster%2016%20Value%20Edition%20Drivers%20%26%20Applications%20disk%20set%20%28revision%201%29.zip" `
  "Creative_SB16_Value_Edition_Revision_1.zip"

Fetch "SB16 Install Disks" `
  "https://ftpmirror2.infania.net/sites/Creative%20Labs/Sound%20Blaster%2016/Sound%20Blaster%2016%20Install%20Disks.zip" `
  "Creative_SB16_Install_Disks.zip"

Fetch "SB16 DOS Installation Disks" `
  "https://ftpmirror2.infania.net/sites/Creative%20Labs/Sound%20Blaster%2016/Sound%20Blaster%2016%20DOS%20Installation%20Disks.rar" `
  "Creative_SB16_DOS_Installation_Disks.rar"

# Preserve the primary Wave Blaster manual page and the independent pinout cross-check.
Fetch "Creative SB16 Getting Started manual page (Wave Blaster Table D-15 source)" `
  "https://manualzz.com/doc/68303449/creative-structures-sound-blaster-16-getting-started" `
  "Creative_SB16_Getting_Started_source.html"

Fetch "ePanorama Wave Blaster pinout cross-check" `
  "https://www.epanorama.net/documents/pc/waveblaster.html" `
  "WaveBlaster_ePanorama_crosscheck.html"

# Yamaha application manual: Quarter/GLODIA exposes it through an archive index.
# Save the index, then discover likely YMF262 links rather than inventing a filename.
$quarter = "https://www.quarter-dev.info/archives.php"
Write-Host "Resolving Yamaha YMF262 application-manual link from Quarter/GLODIA..."
try {
    $q = Invoke-WebRequest -Uri $quarter -Headers $headers -MaximumRedirection 10 -UseBasicParsing -ErrorAction Stop
    $q.Content | Set-Content -Encoding UTF8 (Join-Path $out "Quarter_GLODIA_Yamaha_LSI_archive_index.html")
    Add-Result "Quarter/GLODIA Yamaha LSI archive index" "Quarter_GLODIA_Yamaha_LSI_archive_index.html" $quarter "OK"

    $base = [uri]$quarter
    $candidates = @()
    foreach ($l in $q.Links) {
        $href = [string]$l.href
        $text = [string]$l.innerText
        if (($href -match '(?i)ymf?262|opl3|262') -or ($text -match '(?i)ymf?262|opl3')) {
            try {
                $abs = [uri]::new($base, $href).AbsoluteUri
                $candidates += [pscustomobject]@{Url=$abs; Text=$text}
            } catch {}
        }
    }
    $candidates = $candidates | Sort-Object Url -Unique
    if ($candidates.Count -gt 0) {
        $candidates | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $out "Quarter_YMF262_link_candidates.csv")
        foreach ($c in $candidates) {
            if ($c.Url -match '(?i)\.(pdf|zip|lzh|lha|7z|rar)(\?|$)') {
                $ext = [IO.Path]::GetExtension(([uri]$c.Url).AbsolutePath)
                if (-not $ext) { $ext = ".bin" }
                Fetch "Yamaha YMF262 OPL3 Application Manual candidate" $c.Url ("Yamaha_YMF262_OPL3_Application_Manual" + $ext)
                break
            }
        }
    } else {
        Write-Warning "Quarter page loaded, but no machine-readable YMF262 href was exposed. Use the saved index/source URL interactively."
    }
} catch {
    Write-Warning ("Quarter/GLODIA lookup failed: " + $_.Exception.Message)
    Add-Result "Yamaha YMF262 OPL3 Application Manual" "Quarter_GLODIA_Yamaha_LSI_archive_index.html" $quarter ("FAILED: " + $_.Exception.Message)
}

$csv = Join-Path $here "DOWNLOAD-HASHES.csv"
$results | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csv

Write-Host ""
Write-Host ("Successful resources: {0}/{1}" -f (($results | Where-Object {$_.Status -eq "OK"}).Count), $results.Count)
Write-Host ("Hash log: {0}" -f $csv)

# Build a transport pack with exactly what was successfully retrieved plus provenance.
$zip = Join-Path $here "VMB-SB16-Reference-Pack-2026-09-09.zip"
if (Test-Path $zip) { Remove-Item $zip -Force }

$stage = Join-Path $here "_pack_staging"
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Path $stage | Out-Null
Copy-Item -Recurse -Path $out -Destination $stage
Copy-Item -Path (Join-Path $here "README.md"),
                (Join-Path $here "manifest.csv"),
                (Join-Path $here "manifest.json"),
                (Join-Path $here "WAVEBLASTER-PINOUT-CROSSCHECK.md"),
                (Join-Path $here "SB16-CONFORMANCE-TEST-NOTES.md"),
                $csv -Destination $stage
Compress-Archive -Path (Join-Path $stage "*") -DestinationPath $zip -CompressionLevel Optimal
Remove-Item $stage -Recurse -Force

$zh = Get-FileHash -Algorithm SHA256 -Path $zip
Write-Host ("Final pack: {0}" -f $zip)
Write-Host ("Pack SHA256: {0}" -f $zh.Hash.ToLowerInvariant())
